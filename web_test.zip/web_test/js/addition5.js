document.write("<br>🔵 <b> 비교연산자 </b> <br>");

document.write("<br> 10 == 5 ▶ "+(10==5)+"<br>"); //false
document.write("2.5 == 2.50 ▶ "+(2.5==2.50)+"<br>"); //true
document.write("10 != 5 ▶ "+(10!=5)+"<br>"); //true
document.write("10 < 5 ▶ "+(10<5)+"<br>"); //false
document.write("2.5 <= 2.50 ▶ "+(2.5<=2.50)+"<br>"); //true
document.write("Javascript == javascript ▶ "+("Javascript"=="javascript")+"<br>"); //false
document.write("operator != operatorl ▶ "+("operator"!="operatorl")+"<br>"); //true
document.write("10 <= 10 ▶ "+(10<=10)+"<br>"); //true
document.write("javascript > Javascript ▶ "+("javascript">"Javascript")+"<br>"); //true
//document.write("\"hi") >> "를 함께 출력하고 싶은 경우 \(역슬레시)를 쓴다.

