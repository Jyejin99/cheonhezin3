var a=10, b=4;

res1 = a+b;
res2 = a-b;
res3 = a*b;
res4 = a/b;
res5 = a%b;

document.write("🔵 <b> 산술연산자 : a=10, b=4 </b> <br><br>");
document.write("10+4="+res1+"<br>");
document.write("10-4="+res2+"<br>");
document.write("10*4="+res3+"<br>");
document.write("10/4="+res4+"<br>");
document.write("10%4="+res5+"<br><br>");

var a=10, b=10;

document.write("🔵 <b> 증감연산자 : a=10, b=10 </b> <br><br>");
document.write("a= "+a+"<br>");
document.write("++a= "+(a++)+"<br>");
document.write("a++= "+(++a)+"<br>");
document.write("b= "+b+"<br>");
document.write("++b= "+(b++)+"<br>");
document.write("b++= "+(++b)+"<br><br>");

var a=20, b=6;
a=b;
var c=20, d=6;
c+=d;
var e=20, f=6;
e-=f;
var g=20, h=6;
g*=h;
var i=20, j=6;
i/=j;
var k=20, l=6;
k%=l;

document.write("🔵 <b> 대입연산자 : a=20, b=6 </b> <br><br>");
document.write("a=b ▶ "+a+"<br>");
document.write("a+=b ▶ "+c+"<br>");
document.write("a-=b ▶ "+e+"<br>");
document.write("a*=b ▶ "+g+"<br>");
document.write("a/=b ▶ "+i+"<br>");
document.write("a%=b ▶ "+k+"<br>");

