var today;
today = new Date();
document.write("<br>"+today);
document.getElementById("p1").style.color="red";